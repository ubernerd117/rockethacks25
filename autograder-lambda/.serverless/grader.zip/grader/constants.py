import os

# Google API key for Gemini
GOOGLE_API_KEY = os.environ.get("GOOGLE_API_KEY")